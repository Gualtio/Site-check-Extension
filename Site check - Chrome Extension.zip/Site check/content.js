let isActive = false;

function toggleStyles() {
    isActive = !isActive;
    if (isActive) {
        document.body.classList.add('red-highlight-active');
    } else {
        document.body.classList.remove('red-highlight-active');
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggle") {
        toggleStyles();
    }
}); 